﻿using System;
using System.Collections.Generic;
using System.Text;
using FM;

namespace $safeprojectname$
{
    public class $safeprojectname$Module : FirewallModule
    {
        public $safeprojectname$Module() : base()
        {
            MetaData.Name = "$safeprojectname$Module";
            MetaData.Version = "0.0.1.0";
            MetaData.HelpString = "";
            MetaData.Description = "";
            MetaData.Contact = "";
            MetaData.Author = "";
        }

        public override ModuleError ModuleStart()
        {
            throw new NotImplementedException();
        }

        public override ModuleError ModuleStop()
        {
            throw new NotImplementedException();
        }

        public override PacketMainReturn interiorMain(ref Packet in_packet)
        {
            throw new NotImplementedException();
        }
    }
}
